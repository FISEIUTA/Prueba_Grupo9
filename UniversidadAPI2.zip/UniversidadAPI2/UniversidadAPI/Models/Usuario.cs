﻿namespace UniversidadAPI.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string UsuarioNombre { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
        public string Rol { get; set; } = string.Empty; // Ej: "Admin", "Docente", "Estudiante"
    }
}
