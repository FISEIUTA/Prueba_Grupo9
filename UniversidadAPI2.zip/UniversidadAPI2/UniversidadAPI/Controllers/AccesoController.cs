﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using UniversidadAPI.Data;
using UniversidadAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace UniversidadAPI.Controllers
{
    public class AccesoController : Controller
    {
        private readonly AppDbContext _context;

        public AccesoController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Acceso/Login
        [AllowAnonymous]
        public IActionResult Login()
        {
            // Muestra Views/Acceso/Login.cshtml
            return View();
        }

        // POST: Acceso/Login
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(string usuarioNombre, string contrasena)
        {
            if (string.IsNullOrEmpty(usuarioNombre) || string.IsNullOrEmpty(contrasena))
            {
                TempData["Error"] = "Debe ingresar usuario y contraseña.";
                return View();
            }

            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.UsuarioNombre == usuarioNombre && u.Contrasena == contrasena);

            if (usuario == null)
            {
                TempData["Error"] = "Usuario o contraseña incorrectos.";
                return View();
            }

            // Crear claims (nombre y rol)
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, usuario.UsuarioNombre),
                new Claim(ClaimTypes.Role, usuario.Rol)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            // Iniciar sesión con cookie
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(identity),
                new AuthenticationProperties { IsPersistent = true }
            );

            TempData["Success"] = $"Bienvenido, {usuario.UsuarioNombre}";
            return RedirectToAction("Index", "Home");
        }

        // POST: Acceso/Logout
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Acceso");
        }

        // GET: Acceso/Denegado
        [AllowAnonymous]
        public IActionResult Denegado()
        {
            return View();  // Muestra Views/Home/Denegado.cshtml
        }
    }
}
