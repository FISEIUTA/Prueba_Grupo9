﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using UniversidadAPI.Data;

var builder = WebApplication.CreateBuilder(args);

// 1) Configurar DbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2) Configurar autenticación por cookies
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Acceso/Login";        // vista de login
        options.AccessDeniedPath = "/Acceso/Denegado"; // o "/Home/Denegado"
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
    });

// 3) (Opcional) Sesiones si las necesitas
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// 4) MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

// 5) Middleware pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// 6) Sesión, Autenticación y Autorización
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

// 7) Rutas
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
